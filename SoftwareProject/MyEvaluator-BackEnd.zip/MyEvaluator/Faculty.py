class Faculty(Person):
	def __init__(self):
		self.professors = set_professors()
		self.students = set_students()

	def set_professors(self):
		professors = []
		
		return professors

	def set_students(self):
		
		return  students
