# MyEvaluator
This project is developed as part of the Introduction to software course at the mediterranean institute of technology
