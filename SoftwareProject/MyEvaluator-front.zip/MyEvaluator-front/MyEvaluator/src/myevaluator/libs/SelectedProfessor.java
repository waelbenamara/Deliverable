package myevaluator.libs;

public class SelectedProfessor {
public String professor;
}
