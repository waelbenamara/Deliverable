package myevaluator.libs;

import java.util.ArrayList;

public class GetProfessorsResponse {

	
	private ArrayList<String> professors = new ArrayList<String>();

	public ArrayList<String> getprofessors() {
		return professors;
	}

	public void setprofessors(ArrayList<String> professors) {
		this.professors = professors;
	}
}
