package myevaluator.libs;

import java.util.ArrayList;

public class GetCoursesResponse {

	
	private ArrayList<String> courses = new ArrayList<String>();

	public ArrayList<String> getCourses() {
		return courses;
	}

	public void setCourses(ArrayList<String> courses) {
		this.courses = courses;
	}
}
