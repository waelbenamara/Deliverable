package myevaluator.libs;

public class RandomAnswer {
	private String randomanswer;
	public RandomAnswer (String randomanswer) {
		this.randomanswer=randomanswer;
	}
	public String getRandomanswer() {
		return randomanswer;
	}

	public void setRandomanswer(String randomanswer) {
		this.randomanswer = randomanswer;
	}
}
