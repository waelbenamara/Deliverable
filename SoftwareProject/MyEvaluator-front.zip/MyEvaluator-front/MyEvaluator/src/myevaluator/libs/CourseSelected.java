package myevaluator.libs;

public class CourseSelected {
private static String course;

public static String getCourse() {
  return course;
}

public void setCourse(String course) {
  this.course = course;
}

public CourseSelected(String course) {
  super();
  this.course = course;
}

}
