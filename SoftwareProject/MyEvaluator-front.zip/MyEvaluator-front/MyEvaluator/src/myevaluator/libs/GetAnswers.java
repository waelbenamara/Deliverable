package myevaluator.libs;

import java.util.ArrayList;

public class GetAnswers {
  private ArrayList<String> answers = new ArrayList<String>();

  public ArrayList<String> getAnswers() {
    return answers;
  }

  public void setAnswers(ArrayList<String> answers) {
    this.answers = answers;
  }

}
