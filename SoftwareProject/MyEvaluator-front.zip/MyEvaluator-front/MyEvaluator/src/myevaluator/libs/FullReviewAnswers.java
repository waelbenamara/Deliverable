package myevaluator.libs;

public class FullReviewAnswers {
  private String well;
  private String wrong;
  private String improved;
  private String course;
  private int personid;
  
  public FullReviewAnswers(String well, String wrong, String improved, String course, int personid) {
	super();
	this.well = well;
	this.wrong = wrong;
	this.improved = improved;
	this.course = course;
	this.personid = personid;
}
public int getPersonid() {
	return personid;
}
public void setPersonid(int personid) {
	this.personid = personid;
}
public FullReviewAnswers(String well, String wrong, String improved, String course) {
	super();
	this.well = well;
	this.wrong = wrong;
	this.improved = improved;
	this.course = course;
}
public String getCourse() {
	return course;
}
public void setCourse(String course) {
	this.course = course;
}
public String getWell() {
    return well;
  }
  public FullReviewAnswers(String well, String wrong, String improved) {
    super();
    this.well = well;
    this.wrong = wrong;
    this.improved = improved;
  }
  public void setWell(String well) {
    this.well = well;
  }
  public String getWrong() {
    return wrong;
  }
  public void setWrong(String wrong) {
    this.wrong = wrong;
  }
  public String getImproved() {
    return improved;
  }
  public void setImproved(String improved) {
    this.improved = improved;
  }
}
