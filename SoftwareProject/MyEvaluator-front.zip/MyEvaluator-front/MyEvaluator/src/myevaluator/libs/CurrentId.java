package myevaluator.libs;

public class CurrentId {
 public int currentid;
}
