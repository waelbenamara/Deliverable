package myevaluator.libs;

import java.util.ArrayList;

public class Formresponse {
public static ArrayList<FullReviewAnswers> answers = new ArrayList<FullReviewAnswers>();
}
