package myevaluator.views;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import com.google.gson.Gson;

import myevaluator.libs.Formresponse;
import myevaluator.libs.GetCoursesResponse;
import myevaluator.libs.GetProfessorsResponse;
import myevaluator.libs.Request;
import myevaluator.libs.SelectedProfessor;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AllProfessors extends JFrame{

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					AllProfessors window = new AllProfessors();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AllProfessors() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(94, 18, 282, 188);
		frame.getContentPane().add(scrollPane);
		
		JList list = new JList(getProfessors().toArray());
		scrollPane.setViewportView(list);
		
		JButton btnNewButton = new JButton("See Forms");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ProfessorSelected = list.getSelectedValue().toString();
				SelectedProfessor p = new SelectedProfessor();
				p.professor = ProfessorSelected;
				Request r = new Request();
				Gson gson = new Gson();
				String json = gson.toJson(p);
				System.out.println(json);
				String response = r.SendRequest("http://0.0.0.0:80/get_form","GET",json).toString();
				System.out.println(response);
				JOptionPane.showMessageDialog(null, response);
			}
		});
		btnNewButton.setBounds(177, 227, 117, 29);
		frame.getContentPane().add(btnNewButton);
		
		
	
	}
	
	public ArrayList<String> getProfessors() {
		
		Request r = new Request();
		String data = r.SendRequest("http://0.0.0.0:80/get_professors", "GET","").toString();
		Gson g = new Gson();
		GetProfessorsResponse response = g.fromJson(data, GetProfessorsResponse.class);
		
		
		
		return response.getprofessors();
		
	}
}
